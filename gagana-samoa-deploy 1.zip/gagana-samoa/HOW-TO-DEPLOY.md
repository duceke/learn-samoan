# Gagana Samoa — Deployment Guide
## How to launch for FREE on web + mobile

---

## STEP 1 — Upload to GitHub (free forever)

1. Go to **https://github.com** and sign up for a free account
2. Click the **+** button (top right) → **New repository**
3. Name it: `gagana-samoa`
4. Tick **"Add a README file"**
5. Click **"Create repository"**

### Upload your files:
6. Click **"Add file"** → **"Upload files"**
7. Drag ALL files from this folder into the upload box:
   - `index.html`
   - `manifest.json`
   - `sw.js`
   - `icons/` folder (with icon-192.png and icon-512.png)
8. Click **"Commit changes"**

---

## STEP 2 — Turn on GitHub Pages (your free website)

1. In your repository, click **"Settings"** (top menu)
2. Scroll down to **"Pages"** (left sidebar)
3. Under **"Branch"**, select **main** → **/ (root)**
4. Click **"Save"**
5. Wait 2 minutes — your site goes live at:

   **`https://YOUR-USERNAME.github.io/gagana-samoa`**

That's it! Share this link anywhere — it's live on the internet forever, free!

---

## STEP 3 — Install as a Mobile App (PWA)

The app is already set up as a PWA (Progressive Web App). No app store needed!

### On Android (Chrome):
1. Open your website in Chrome
2. Tap the **3-dot menu** (top right)
3. Tap **"Add to Home screen"**
4. Tap **"Add"** — it installs like a real app with an icon!

### On iPhone (Safari):
1. Open your website in Safari
2. Tap the **Share button** (box with arrow)
3. Scroll down and tap **"Add to Home Screen"**
4. Tap **"Add"** — done! It appears on your home screen.

### What the PWA gives you:
- Works offline (after first visit)
- Looks like a native app (no browser bar)
- Has its own icon on the home screen
- Fast loading (cached)

---

## STEP 4 — Custom domain (optional, still free)

Want `gaganasamoa.com` instead of the GitHub URL?

1. Buy a domain from **Namecheap** (~$10/year) or **Cloudflare** (at cost)
2. In GitHub Pages settings, add your custom domain
3. Point your domain's DNS to GitHub's servers (GitHub shows the instructions)

---

## Quick share links to give people

Once live, share these:

- **Website:** `https://YOUR-USERNAME.github.io/gagana-samoa`
- **QR code:** Go to `qr.io` (free), paste your URL, download the QR code

---

## Files in this package

| File | What it does |
|------|-------------|
| `index.html` | The entire app — all 11 sections, all content |
| `manifest.json` | Makes it installable as a mobile app |
| `sw.js` | Service worker — makes it work offline |
| `icons/icon-192.png` | App icon (small) |
| `icons/icon-512.png` | App icon (large, for splash screens) |

---

## Need help?

If you get stuck on any step, take a screenshot and share it — happy to help!

**Fa'afetai tele lava! — Thank you very much!** 🌺
